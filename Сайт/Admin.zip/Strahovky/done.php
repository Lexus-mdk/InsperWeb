<?php 
require '../db/db.php';
require '../header.php';

// Страница объявляющая успешную отправку заявки
?>
<div class="container text-left" style="height: 600px;">
    <h1 class="text-center"><br />Спасибо за вашу заявку!<br />В ближайшее время мы ответим вам на почту)</h1>
</div>
<? require "../footer.php";?>