<?php 


mail('lesha.buhvin@mail.ru', "<h1>Проверка</h1>", "Проверка");
?>