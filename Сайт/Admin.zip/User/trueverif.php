<?php
require '../header.php'; ?>



<div class="container text-left" style="height: 600px;">
    <h1 class="text-center"><br>Поздравляю! Вы успешно подтвердили свою почту!</h1><h2 class="text-center"><br>Теперь вы можете получить свой кэшбек в личном кабинете!</h2>
</div>


<? require "../footer.php";?>