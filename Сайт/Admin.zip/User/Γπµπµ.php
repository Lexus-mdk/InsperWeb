<?php 

// Не помню что это, но возможно пригодится

 if ($_SESSION['logged_user']->cash = '')
 {
    
 }

  




    ?>
