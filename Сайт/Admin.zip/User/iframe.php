<?php 

require '../header.php';

?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<!-- <div class="container">
<iframe id="https://agentpolis.ru/4e3bd263528badfae62199b6ac5fbe7cb4e81dec/eosago#/" scrolling="no" src="https://agentpolis.ru/4e3bd263528badfae62199b6ac5fbe7cb4e81dec/eosago?iframe=agent_widget&amp;bgColor=%23ffffff&amp;titleColor=%23000000&amp;primaryColor=%236A1408&amp;secondaryColor=%231e1913&amp;mainTitle=&amp;prolongAlfa=&amp;prolongIngos=&amp;utm_webmaster=&amp;utm_transitionid=" style="width: 100%; border: none; margin: 0px; padding: 0px;"></iframe>
</div>
 -->
<!-- Соотношение сторон 16:9 -->

<div class="embed-responsive embed-responsive-1by1">
  <iframe class="embed-responsive-item" src="https://agentpolis.ru/4e3bd263528badfae62199b6ac5fbe7cb4e81dec/eosago#/" allowtransparency></iframe>
</div>

</body>
</html>


<? require "../footer.php";?>