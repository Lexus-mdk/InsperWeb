<?php
require '../db/db.php';


$verUser = R::findOne('users', 'token = ?', );

$verUser->verif = 1;
R::store($verUser);
header('Location:../User/trueverif');


?>