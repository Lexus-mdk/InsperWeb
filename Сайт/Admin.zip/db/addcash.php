<?php

// require 'db.php';


// $us = R::loadAll('users');
// $user = R::dispense('cash');
//             $user->id = $us->id;
            
//             $user->cash = 0;
//             R::store($user);
// $s = 0;

// if ($s == ) {
// 	print('auf');
// }else{
// 	print('gg');
// }