    <div class=" footer-clean">
        <footer>
            <div class="container">
                <div class="row justify-content-center">
                	<div class="col-sm-4 col-md-3 text-left item">
					    <h3 class="text-center">Страховки</h3>
					    <div class="row">
					        <div class="col text-center">
					            <ul>
					                <li><a href="#">Осаго</a></li>
					                <li><a href="#">Каско</a></li>
					                <li><a href="#">Имущество</a></li>
					            </ul>
					        </div>
					        <div class="col text-center">
					            <ul>
					                <li><a href="#">Жизнь</a></li>
					                <li><a href="#">ДМС</a></li>
					                <li><a href="#">Частный случай</a></li>
					            </ul>
					        </div>
					    </div>
					</div>
                    <div class="col-sm-4 col-md-3 text-center item">
					    <h3>Информация</h3>
					    <ul>
					        <li><a href="#">О компании</a></li>
					        <li><a href="#">Вопросы</a></li>
					        <li><a href="#">Техподдержка</a></li>
					    </ul>
					</div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3>Форум</h3>
                        <ul>
                            <li><a href="../Communication/news.php">Новости</a></li>
                            <li><a href="../Communication/asks.php">Вопросы</a></li>
                            <li><a href="../Communication/consultation.php">Консультация</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 item social" style="width: -138px;padding: 0px;"><a class="text-center" href="https://vk.com/insperru"><i class="fab fa-vk"></i></a>
                        <p class="copyright">InsperWeb © 2020</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/js/chart.min.js"></script>
    <script src="../assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.3.1/js/swiper.jquery.min.js"></script>
    <script src="../assets/js/Simple-Slider.js"></script>
    <script src="../assets/js/theme.js"></script>
</body>

</html>