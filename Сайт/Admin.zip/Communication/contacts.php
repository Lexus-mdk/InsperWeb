<?php 
require '../db/db.php';

// Страница с контактами

require '../header.php'; ?>
    <div class="container">
        <h1 class="text-center">Контакты&nbsp;</h1>
        <p>Вы можете связаться с нами написав на почту: polis@insper.ru<br><br>Или позвонив по номеру +7000000000<br><br>Также вы можете прийти в наш офис по адресу г. Санкт-Петербург,&nbsp;Кондратьевский проспект, 40. <br>Мы находимся на первом этаже универмага
            "Калининский"<br><br>Дни работы:<br><br>Пн&nbsp;10:00 - 20:00<br>Вт&nbsp;10:00 - 20:00<br>Ср&nbsp;10:00 - 20:00<br>Чт&nbsp;10:00 - 20:00<br>Пт&nbsp;10:00 - 20:00<br>Сб&nbsp;11:00 - 19:00<br>Вс&nbsp;11:00 - 19:00<br></p>
    </div>
    <div class="map-clean"><iframe allowfullscreen="" frameborder="0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA4z01d9VjtRuZS91GrBgpJqC_qC04sBnw&amp;q=Russia%2C+%D0%9A%D0%BE%D0%BD%D0%B4%D1%80%D0%B0%D1%82%D1%8C%D0%B5%D0%B2%D1%81%D0%BA%D0%B8%D0%B9+%D0%BF%D1%80.%2C+40&amp;zoom=15"
            width="100%" height="450"></iframe></div>
    <? require "../footer.php";?>