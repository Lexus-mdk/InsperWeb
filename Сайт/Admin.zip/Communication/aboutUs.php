<?php 
require '../db/db.php';

// Страница О нас

require '../header.php'; ?>
    <div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center" style="margin-top: 55px;">О компании Insper</h1>
            </div>
        </div>
        <div class="row" style="margin-right: 0px;margin-left: 0px;">
            <div class="col-md-6" style="width: 500px;padding-right: 15px;"><img src="../assets/img/insper.png" style="width: 500px;height: 500px;min-width: 50px;min-height: 50px;max-height: 500px;max-width: 500px;margin-left: -15px;margin-right: -15px;margin-bottom: 0px;" /></div>
            <div class="col-md-6" style="font-size: 23px;margin-top: 120px;height: 364px;">
                <p style="margin-top: 0px;">Insper Страхование - это сплоченный коллектив из профессиональных страховых агентов, сотрудничающих со всеми ведущими страховыми компаниями Санкт-Петербурга. Наш опыт в сфере страхования насчитывает уже более 10 лет и мы готовы поделиться
                    им на благо наших клиентов.<br /></p>
            </div>
        </div>
    </div>
</div>
<? require "../footer.php";?>